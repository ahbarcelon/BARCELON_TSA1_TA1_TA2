<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<header class="page-head">
    <p class="eyebrow">Full schedule</p>
    <h1>All Tasks</h1>
    <p class="lede">Every task in the database, ordered by date.</p>
</header>

<?php if (empty($tasks)): ?>
    <section class="card empty-state">
        <h2>No tasks yet</h2>
        <p>The tasks table is empty. Run <code>php spark db:seed TasksTodaySeeder</code> to add sample tasks.</p>
    </section>
<?php else: ?>
    <?= $this->include('partials/summary') ?>
    <?php $caption = 'All tasks ordered by date'; ?>
    <?= $this->include('partials/task_table') ?>
<?php endif; ?>
<?= $this->endSection() ?>

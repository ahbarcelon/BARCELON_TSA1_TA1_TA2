<?php
helper('url');
$path  = trim(uri_string(), '/');
$links = [
    ''        => 'Today',
    'tasks'   => 'All Tasks',
    'profile' => 'Profile',
    'about'   => 'About',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? 'Tasks for Today') ?> | Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>
    <a class="skip-link" href="#main">Skip to content</a>

    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="<?= site_url('/') ?>">Tasks for Today</a>
            <nav aria-label="Main navigation">
                <ul class="nav-list">
                    <?php foreach ($links as $slug => $label): ?>
                        <li>
                            <a href="<?= site_url($slug) ?>"
                               class="nav-link<?= $path === $slug ? ' is-active' : '' ?>"
                               <?= $path === $slug ? 'aria-current="page"' : '' ?>><?= esc($label) ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main id="main" class="container page">
        <?= $this->renderSection('content') ?>
    </main>

    <footer class="site-footer">
        <div class="container">Tasks for Today Management System &middot; CodeIgniter 4 &amp; MySQL</div>
    </footer>
</body>
</html>

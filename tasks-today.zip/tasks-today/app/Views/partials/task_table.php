<?php
/** @var array $tasks */
$todayKey = date('Y-m-d');
?>
<div class="card table-card">
    <table class="task-table">
        <caption class="visually-hidden"><?= esc($caption ?? 'Task list') ?></caption>
        <thead>
            <tr>
                <th scope="col">Task</th>
                <th scope="col">Status</th>
                <th scope="col">Task date</th>
                <th scope="col">Created</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($tasks as $task): ?>
            <?php $slug = str_replace(' ', '-', $task['status']); ?>
            <tr>
                <th scope="row" class="task-title"><?= esc($task['title']) ?></th>
                <td data-label="Status"><span class="badge badge-<?= esc($slug, 'attr') ?>"><?= esc(ucfirst($task['status'])) ?></span></td>
                <td data-label="Task date">
                    <span><time datetime="<?= esc($task['task_date'], 'attr') ?>"><?= date('M j, Y', strtotime($task['task_date'])) ?></time>
                    <?php if ($task['task_date'] === $todayKey): ?><span class="today-tag">Today</span><?php endif; ?></span>
                </td>
                <td data-label="Created"><time datetime="<?= esc($task['created_at'], 'attr') ?>"><?= date('M j, Y g:i A', strtotime($task['created_at'])) ?></time></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
